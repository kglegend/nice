﻿namespace SuperAdventure
{
    partial class SuperAdventure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblhp = new System.Windows.Forms.Label();
            this.lblmp = new System.Windows.Forms.Label();
            this.lblsta = new System.Windows.Forms.Label();
            this.lbllvl = new System.Windows.Forms.Label();
            this.lblxp = new System.Windows.Forms.Label();
            this.lblsauce = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cboWeapons = new System.Windows.Forms.ComboBox();
            this.cboPotions = new System.Windows.Forms.ComboBox();
            this.btnNorth = new System.Windows.Forms.Button();
            this.btnSouth = new System.Windows.Forms.Button();
            this.btnEast = new System.Windows.Forms.Button();
            this.btnWest = new System.Windows.Forms.Button();
            this.btnUseWeapon = new System.Windows.Forms.Button();
            this.btnUsePotion = new System.Windows.Forms.Button();
            this.rtbLocation = new System.Windows.Forms.RichTextBox();
            this.ttbMessages = new System.Windows.Forms.RichTextBox();
            this.dgvInvintory = new System.Windows.Forms.DataGridView();
            this.dgvQuests = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvintory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuests)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "HP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sauce";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Xp";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(145, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Level";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "MP";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Stamina";
            // 
            // lblhp
            // 
            this.lblhp.AutoSize = true;
            this.lblhp.Location = new System.Drawing.Point(110, 19);
            this.lblhp.Name = "lblhp";
            this.lblhp.Size = new System.Drawing.Size(0, 18);
            this.lblhp.TabIndex = 7;
            // 
            // lblmp
            // 
            this.lblmp.AutoSize = true;
            this.lblmp.Location = new System.Drawing.Point(110, 45);
            this.lblmp.Name = "lblmp";
            this.lblmp.Size = new System.Drawing.Size(0, 18);
            this.lblmp.TabIndex = 8;
            // 
            // lblsta
            // 
            this.lblsta.AutoSize = true;
            this.lblsta.Location = new System.Drawing.Point(110, 74);
            this.lblsta.Name = "lblsta";
            this.lblsta.Size = new System.Drawing.Size(0, 18);
            this.lblsta.TabIndex = 9;
            // 
            // lbllvl
            // 
            this.lbllvl.AutoSize = true;
            this.lbllvl.Location = new System.Drawing.Point(638, 19);
            this.lbllvl.Name = "lbllvl";
            this.lbllvl.Size = new System.Drawing.Size(0, 18);
            this.lbllvl.TabIndex = 10;
            // 
            // lblxp
            // 
            this.lblxp.AutoSize = true;
            this.lblxp.Location = new System.Drawing.Point(638, 45);
            this.lblxp.Name = "lblxp";
            this.lblxp.Size = new System.Drawing.Size(0, 18);
            this.lblxp.TabIndex = 11;
            // 
            // lblsauce
            // 
            this.lblsauce.AutoSize = true;
            this.lblsauce.Location = new System.Drawing.Point(638, 74);
            this.lblsauce.Name = "lblsauce";
            this.lblsauce.Size = new System.Drawing.Size(0, 18);
            this.lblsauce.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 283);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 18);
            this.label5.TabIndex = 13;
            this.label5.Text = "Select Action";
            // 
            // cboWeapons
            // 
            this.cboWeapons.FormattingEnabled = true;
            this.cboWeapons.Location = new System.Drawing.Point(21, 304);
            this.cboWeapons.Name = "cboWeapons";
            this.cboWeapons.Size = new System.Drawing.Size(121, 26);
            this.cboWeapons.TabIndex = 14;
            // 
            // cboPotions
            // 
            this.cboPotions.FormattingEnabled = true;
            this.cboPotions.Location = new System.Drawing.Point(21, 336);
            this.cboPotions.Name = "cboPotions";
            this.cboPotions.Size = new System.Drawing.Size(121, 26);
            this.cboPotions.TabIndex = 15;
            // 
            // btnNorth
            // 
            this.btnNorth.Location = new System.Drawing.Point(564, 266);
            this.btnNorth.Name = "btnNorth";
            this.btnNorth.Size = new System.Drawing.Size(59, 23);
            this.btnNorth.TabIndex = 16;
            this.btnNorth.Text = "North";
            this.btnNorth.UseVisualStyleBackColor = true;
            this.btnNorth.Click += new System.EventHandler(this.btnNorth_Click);
            // 
            // btnSouth
            // 
            this.btnSouth.Location = new System.Drawing.Point(564, 339);
            this.btnSouth.Name = "btnSouth";
            this.btnSouth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSouth.Size = new System.Drawing.Size(59, 23);
            this.btnSouth.TabIndex = 17;
            this.btnSouth.Text = "South";
            this.btnSouth.UseVisualStyleBackColor = true;
            this.btnSouth.Click += new System.EventHandler(this.btnSouth_Click);
            // 
            // btnEast
            // 
            this.btnEast.Location = new System.Drawing.Point(508, 304);
            this.btnEast.Name = "btnEast";
            this.btnEast.Size = new System.Drawing.Size(49, 23);
            this.btnEast.TabIndex = 18;
            this.btnEast.Text = "East";
            this.btnEast.UseVisualStyleBackColor = true;
            this.btnEast.Click += new System.EventHandler(this.btnEast_Click);
            // 
            // btnWest
            // 
            this.btnWest.Location = new System.Drawing.Point(628, 304);
            this.btnWest.Name = "btnWest";
            this.btnWest.Size = new System.Drawing.Size(52, 23);
            this.btnWest.TabIndex = 19;
            this.btnWest.Text = "West";
            this.btnWest.UseVisualStyleBackColor = true;
            this.btnWest.Click += new System.EventHandler(this.btnWest_Click);
            // 
            // btnUseWeapon
            // 
            this.btnUseWeapon.Location = new System.Drawing.Point(159, 304);
            this.btnUseWeapon.Name = "btnUseWeapon";
            this.btnUseWeapon.Size = new System.Drawing.Size(58, 24);
            this.btnUseWeapon.TabIndex = 20;
            this.btnUseWeapon.Text = "Use";
            this.btnUseWeapon.UseVisualStyleBackColor = true;
            this.btnUseWeapon.Click += new System.EventHandler(this.btnUseWeapon_Click);
            // 
            // btnUsePotion
            // 
            this.btnUsePotion.Location = new System.Drawing.Point(159, 337);
            this.btnUsePotion.Name = "btnUsePotion";
            this.btnUsePotion.Size = new System.Drawing.Size(58, 25);
            this.btnUsePotion.TabIndex = 21;
            this.btnUsePotion.Text = "Use";
            this.btnUsePotion.UseVisualStyleBackColor = true;
            this.btnUsePotion.Click += new System.EventHandler(this.btnUsePotion_Click);
            // 
            // rtbLocation
            // 
            this.rtbLocation.Location = new System.Drawing.Point(240, 254);
            this.rtbLocation.Name = "rtbLocation";
            this.rtbLocation.ReadOnly = true;
            this.rtbLocation.Size = new System.Drawing.Size(240, 35);
            this.rtbLocation.TabIndex = 22;
            this.rtbLocation.Text = "";
            // 
            // ttbMessages
            // 
            this.ttbMessages.Location = new System.Drawing.Point(240, 283);
            this.ttbMessages.Name = "ttbMessages";
            this.ttbMessages.ReadOnly = true;
            this.ttbMessages.Size = new System.Drawing.Size(240, 90);
            this.ttbMessages.TabIndex = 23;
            this.ttbMessages.Text = "";
            // 
            // dgvInvintory
            // 
            this.dgvInvintory.AllowUserToAddRows = false;
            this.dgvInvintory.AllowUserToDeleteRows = false;
            this.dgvInvintory.AllowUserToResizeRows = false;
            this.dgvInvintory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvintory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvInvintory.Enabled = false;
            this.dgvInvintory.Location = new System.Drawing.Point(12, 109);
            this.dgvInvintory.MultiSelect = false;
            this.dgvInvintory.Name = "dgvInvintory";
            this.dgvInvintory.ReadOnly = true;
            this.dgvInvintory.RowHeadersVisible = false;
            this.dgvInvintory.Size = new System.Drawing.Size(205, 168);
            this.dgvInvintory.TabIndex = 24;
            // 
            // dgvQuests
            // 
            this.dgvQuests.AllowUserToAddRows = false;
            this.dgvQuests.AllowUserToDeleteRows = false;
            this.dgvQuests.AllowUserToResizeRows = false;
            this.dgvQuests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuests.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvQuests.Enabled = false;
            this.dgvQuests.Location = new System.Drawing.Point(564, 1);
            this.dgvQuests.MultiSelect = false;
            this.dgvQuests.Name = "dgvQuests";
            this.dgvQuests.ReadOnly = true;
            this.dgvQuests.Size = new System.Drawing.Size(152, 150);
            this.dgvQuests.TabIndex = 25;
            // 
            // game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 651);
            this.Controls.Add(this.dgvQuests);
            this.Controls.Add(this.dgvInvintory);
            this.Controls.Add(this.ttbMessages);
            this.Controls.Add(this.rtbLocation);
            this.Controls.Add(this.btnUsePotion);
            this.Controls.Add(this.btnUseWeapon);
            this.Controls.Add(this.btnWest);
            this.Controls.Add(this.btnEast);
            this.Controls.Add(this.btnSouth);
            this.Controls.Add(this.btnNorth);
            this.Controls.Add(this.cboPotions);
            this.Controls.Add(this.cboWeapons);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblsauce);
            this.Controls.Add(this.lblxp);
            this.Controls.Add(this.lbllvl);
            this.Controls.Add(this.lblsta);
            this.Controls.Add(this.lblmp);
            this.Controls.Add(this.lblhp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Help;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "game";
            this.Text = "super cool game pt. 1: lmao";
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvintory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblhp;
        private System.Windows.Forms.Label lblmp;
        private System.Windows.Forms.Label lblsta;
        private System.Windows.Forms.Label lbllvl;
        private System.Windows.Forms.Label lblxp;
        private System.Windows.Forms.Label lblsauce;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboWeapons;
        private System.Windows.Forms.ComboBox cboPotions;
        private System.Windows.Forms.Button btnNorth;
        private System.Windows.Forms.Button btnSouth;
        private System.Windows.Forms.Button btnEast;
        private System.Windows.Forms.Button btnWest;
        private System.Windows.Forms.Button btnUseWeapon;
        private System.Windows.Forms.Button btnUsePotion;
        private System.Windows.Forms.RichTextBox rtbLocation;
        private System.Windows.Forms.RichTextBox ttbMessages;
        private System.Windows.Forms.DataGridView dgvInvintory;
        private System.Windows.Forms.DataGridView dgvQuests;
    }
}

