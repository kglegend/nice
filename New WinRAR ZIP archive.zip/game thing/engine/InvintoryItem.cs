﻿
using engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    public class InventoryItem
    {
        public item Details { get; set; }
        public int Quantity { get; set; }

        public InventoryItem(item details, int quantity)
        {
            Details = details;
            Quantity = quantity;
        }
    }
}