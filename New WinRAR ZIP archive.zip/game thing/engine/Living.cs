﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace engine
{
    public class Living
    {

        public int MaxHP { get; set;}
        public int CurrHP { get; set;}


        public Living(int currHP, int maxHP)
        {
            CurrHP = currHP;
            MaxHP = maxHP;
        }

    }
}
